<?php get_header(); ?>

<div class="container">
	<?php the_content(); ?>
</div>

<?php get_footer(); ?>