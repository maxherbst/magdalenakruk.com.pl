				<footer>
					<a href="mailto:lena.kruk@gmail.com">lena.kruk@gmail.com</a><br><br><br>
					<span class='copyrights'>Developed<br/>by<br/>Raven/Herbst</span><br>
				</footer>
			</div>
			<?php wp_footer(); ?>
		</div>
    </body>
</html>