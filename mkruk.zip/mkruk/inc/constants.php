<?php define('WP_THEME_URL',get_bloginfo('template_directory')); ?>
